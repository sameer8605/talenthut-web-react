export { default } from "./footer";
