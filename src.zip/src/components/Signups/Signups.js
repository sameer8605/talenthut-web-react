import React, { useState,useEffect, createContext } from "react";
import GoogleLogin from 'react-google-login';
import validator from 'validator';
import { Redirect, useHistory } from 'react-router-dom'
import {
  Button,
  TextField,
  Grid,
  Paper,
  Link,
} from "@material-ui/core";



const Signups = () => {
   
   const history = useHistory();
   const [userName,setUsername] = useState("");
   const [email,setEmail] = useState("");
   const [password,setPassword] = useState("");
   const [confirmPassword,setConfirmpassword] = useState("");
   const [next,setNext] = useState(false);
   const [phoneNumber,setNumber] = useState("");
   //const [roll,setRoll] = useState("student");

const [validemail,setvalidEmail] = useState("")


const responseGoogle = (response) => {
   console.log(response);
 }

 const validateusername = (e) => {
   // let email = e.target.value    
     setUsername(e.target.value)
     
   
 }

const validateEmail = (e) => {
  // let email = e.target.value    
    setEmail(e.target.value)
    if ((validator.isEmail(e.target.value))) {
    setvalidEmail('')
    }
   else {
    setvalidEmail('Enter valid number! OR Valid phone number')
  }
  
}

const validatePassword = (e) => {
   // let email = e.target.value    
     setPassword(e.target.value)
     
   
 }

 

 const validateConfirmpassword = (e) => {
   // let email = e.target.value    
     setConfirmpassword(e.target.value)
     
 }

 const validateNumber = (e) => {
   // let email = e.target.value    
     setNumber(e.target.value)
     
   
 }





  async function login(){
   //const data = {userName,email,password,confirmpassword,phoneNumber};
   
   //console.log(data)

   const result = await fetch("http://talent-hub-backend.herokuapp.com/api/registration", {
     method: "POST",
     headers: {
       "Content-Type": "application/json"
     },
     body: JSON.stringify({userName:userName,email:email,password:password,roll:"student",confirmPassword:confirmPassword,phoneNumber:phoneNumber})
   })
   const res = await result.json();
   console.log(res);

   if(res.success === true){
     // window.location.href = "/";
     console.log(res)
   }
   else{
      alert("incorrect credential")
   }   
 };


  return (
     
    <div class="container">
    <div className="row">
      {/* {next && go()} */}

       <Grid container spacing={0} justify="center" direction="row">

          <Grid item>
             <Grid
                container
                direction="column"
                justify="center"
                spacing={2}
                className="login-form">
                <Paper
                   variant="elevation"
                   elevation={2}
                   className="login-background">

                                     <Grid item>
                                    <h1 style={{textAlign:'center',fontSize:'20px',color:'#fff',backgroundColor:'orange',padding:'30px 0px',margin:'-65px',borderRadius:'10px 10px 0 0'}}>
                                   <center>LOGIN TO YOUR ACCOUNT</center></h1>

                                   <GoogleLogin
    clientId="274074637494-s2fbta7752oii5904is867d05eiff735.apps.googleusercontent.com"
    render={renderProps => (
      <button onClick={renderProps.onClick} 
      disabled={renderProps.disabled} 
      style={{backgroundColor:'#E21919',color:'#fff',marginTop:'100px',padding:'8px 129px 8px 129px'}}>
  <img src="./Googles.png" style={{height:'30px',width:'30px',marginLeft:'-25px'}}></img>Sign In with Google</button>
    )}
    buttonText="Login"
    onSuccess={responseGoogle}
    onFailure={responseGoogle}
    cookiePolicy={'single_host_origin'}
  />
  <p className = "textAlignCen">
     <span className = "line"></span>
     <span className = "or">Or</span>
     <span className = "line"></span>
  </p>
  <p className="proLogin"><center>Use Talenthunt Login</center></p>
                      <form>
                         
                         <Grid container direction="column" spacing={2} >
                            <Grid item>
                               <TextField
                                  type="text"
                                  placeholder="Username"
                                  fullWidth
                                  name="username"
                                  variant="outlined"
                                  onChange = {(e)=>validateusername(e)}
                                  value = {userName}
                                  required
                                  autoFocus
                               />    
                            </Grid>
                            <Grid item>
                               <TextField
                                  type="email"
                                  placeholder="Email ID"
                                  fullWidth
                                  name="email"
                                  variant="outlined"
                                  onChange = {(e)=>validateEmail(e)}
                                  value = {email}
                                  required
                                  autoFocus
                               />    
                            </Grid>
                            <Grid item>
                               <TextField
                                  type="password"
                                  placeholder="Password"
                                  fullWidth
                                  name="password"
                                  variant="outlined"
                                  onChange = {(e)=>validatePassword(e)}
                                  value = {password}
                                  required
                                  autoFocus
                               />    
                            </Grid>
                            <Grid item>
                               <TextField
                                  type="password"
                                  placeholder="confirmpassword"
                                  fullWidth
                                  name="confirmpassword"
                                  variant="outlined"
                                  onChange = {(e)=>validateConfirmpassword(e)}
                                  value = {confirmPassword}
                                  required
                                  autoFocus
                               />    
                            </Grid>
                            <Grid item>
                               <TextField
                                  type="number"
                                  placeholder="Phone Number"
                                  fullWidth
                                  name="email"
                                  variant="outlined"
                                  onChange = {(e)=>validateNumber(e)}
                                  value = {phoneNumber}
                                  required
                                  autoFocus
                               />    
                            </Grid>
                            <span style={{color:'red'}}> {validemail}</span>
                            
                            
                            <Grid item>
                              <center> <Button
                               style={{width:"150px"}}
                                  variant="contained"
                                  color="primary"
                                  type="submit"
                                  className="button-blocks" onClick={(event) => {
                                     event.preventDefault();
                                     //setNext(true);
                                     login();
                                  }}>
                                  Next
                                        </Button></center>
                            </Grid>
                         </Grid>
                      </form>
                   </Grid>
                   <Grid item>
                     <center><p>New User?<a href="#">Sign Up Now!</a>it's <span style={{color:'orange'}}>FREE</span></p></center>
                   </Grid>
                </Paper>
             </Grid>
          </Grid>
       </Grid>
    </div>
 </div>
  )
};

export default Signups;

// we use redirect method please check line no 19&64 otherwise u won't understand it.
