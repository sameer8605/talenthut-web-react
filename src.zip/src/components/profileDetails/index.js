export { default } from "./profileDetails";
