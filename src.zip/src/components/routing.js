import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import Home from "../components/home/home";
import Signin from "../components/signin/signin";
import SigninTwo from "../components/SigninTwo/SigninTwo";
import SigninOtp from "../components/SigninOtp/SigninOtp";
import Email from "../components/forget-password/Email/Email";
import Password from "../components/forget-password/password/Password";
import Signup from "../components/signup/signup";
import Signups from "../components/Signups/Signups";
import Courses from "../components/courses/courses";
import ProfileDetails from "../components/profileDetails/profileDetails";
import SignupEmployer from "../components/signup/signupEmpoyer";
import PostProject from "../components/signup/postProject";
import SignupEmployee from "../components/signup/signupEmployee";
import Empskills from "../components/signup/empskills";
import Jobs from "../components/jobs/jobs";
import Membership from "../components/signup/membership";
import SignupTutor from "../components/signup/signupTutor";
import Tutordetails from "../components/signup/tutordetails";
import Institute from "../components/signup/institute";
import InstituteDetails from "../components/signup/instidetails";
import Student from "../components/signup/signupStudent";
import PostRequirement from "./signup/postRequirement";
import ForgotEmail from "../components/forget-password/Email/Email";
import ForgotPassword from "../components/forget-password/password/Password"

export default function Routing() {
  return (
    
      <div>
        <hr />
        
        <Switch>

          <Route exact path="/" component={Home}/>
          <Route path="/courses"> <Courses /> </Route>
          <Route path="/profiledetails"> <ProfileDetails /> </Route>
          <Route path="/signupemployer"> <SignupEmployer /> </Route>
          <Route path="/postproject"> <PostProject /> </Route>
          <Route path="/signupemployee"> <SignupEmployee /> </Route>
          <Route path="/signin" component={Signin}/>
          <Route path="/signintwo" component={SigninTwo}/>
          <Route path="/email" component={Email}/>
          <Route path="/password" component={Password}/>
          <Route path="/signinotp" component={SigninOtp}/>
          <Route path="/signup" component={Signup}/> 
          <Route path="/signups" component={Signups}/> 
          <Route path="/empskills"> <Empskills /> </Route>
          <Route path="/jobs"> <Jobs /> </Route>
          <Route path="/membership"> <Membership /> </Route>
          <Route path="/signupTutors"> <SignupTutor /> </Route>
          <Route path="/tutorDetails"> <Tutordetails /> </Route>
          <Route path="/instituteSignup"> <Institute /> </Route>
          <Route path="/instituteDetails"> <InstituteDetails /> </Route>
          <Route path="/studentSignup"> <Student /> </Route>
          <Route path="/postRequirement"> <PostRequirement /> </Route>
          <Route exact path="/forgot-email" component={ForgotEmail}/> 
          <Route exact path="/forgot-password" component={ForgotPassword}/>
        </Switch>
      </div>
    
  );
}