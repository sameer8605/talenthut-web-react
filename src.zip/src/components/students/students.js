import React from "react";

const students = () => {
  return <div />;
};

export default students;
