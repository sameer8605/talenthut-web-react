export { default } from "./students";
