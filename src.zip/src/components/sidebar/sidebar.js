import React from "react";

const sidebar = () => {
  return <div />;
};

export default sidebar;
