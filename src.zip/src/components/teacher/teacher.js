import React from "react";

const teacher = () => {
  return <div />;
};

export default teacher;
