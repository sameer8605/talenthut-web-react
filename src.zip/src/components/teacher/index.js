export { default } from "./teacher";
