export { default } from "./signup";
